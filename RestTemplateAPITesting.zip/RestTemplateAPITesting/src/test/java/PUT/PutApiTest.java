package PUT;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.Test;


public class PutApiTest {
    private   RestTemplate restTemplate = new RestTemplate();
    private String baseUrl = "https://jsonplaceholder.typicode.com/posts";


    @Test(description = "PUT API Test cases")
    public void TestPUTapi()
    {
        String requestBody =  "{ \"title\": \"Viren\", \"body\": \"Only for Testing\", \"userId\": 1 }";

        //Set Headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json");

        // Create HttpEntity object with body and headers
        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);

        //Send POST Request
        ResponseEntity<String> response  =  restTemplate.postForEntity(baseUrl,requestBody,String.class);

        //Verify the Assertion

        Assert.assertEquals(response.getStatusCodeValue(),201);
        Assert.assertNotNull(response);
        System.out.println("Response Body: " + response);

    }
}
